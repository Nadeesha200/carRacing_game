package com.example.myrace

interface GameTask {
    fun closeGame(mScore:Int)
}